#pragma once

#include <string>

enum class ArgMode {
	notset,
	conceal,
	recover
};

enum class ArgOption {
	none,
	bluesky,
	reddit
};

struct ProgramArgs {
	ArgMode mode = ArgMode::notset;
	ArgOption platform = ArgOption::none;
    	std::string cover_image;
    	std::string pin_file;
    	std::string data_file;
    	
    	static ProgramArgs parse(int argc, char** argv);
};


