<?php

session_start();

$jdvrifDir = "/var/www/cleasbycode.co.uk/html/jdvrif/";
$uploadDir = "uploads/";

$userAgent = $_SERVER['HTTP_USER_AGENT'];

if (strpos($userAgent, 'Mobile') == true) {
	echo "<style> body{background-color:#111111;color:aliceblue;font-family:Math;font-size:2.3em;text-align:center;min-height:100vh;}";
	echo "h1{font-size:2.7em;font-weight:bold;margin-top:38px;margin-bottom:20px;color:#faaaaa;}img{max-width: 42%; max-height: 33%;border:2px solid silver;border-radius:14px;}p{margin: 4px 0;line-height: 1.3;}button:focus,button:active{outline:none;}</style>";
} else { 
	echo "<style> body{background-color:#111111;color:aliceblue;font-family:Math;font-size:1.6em;text-align:center;}";
	echo "h1{font-size:1.7em;font-weight:bold;margin-top:24px;margin-bottom:-12px;color:#faaaaa;}img{max-width: 22%; max-height: 14%;border:2px solid silver;border-radius:14px;}img:hover{border-color:orange;}p{margin:6px 0;line-height:1.4;}button:focus,button:active{outline:none;}</style>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	$redditOption = isset($_POST['reddit']) && $_POST['reddit'] === '-r';
    $blueskyOption = isset($_POST['bluesky']) && $_POST['bluesky'] === '-b';

    if (
        isset($_FILES["image"]) && $_FILES["image"]["error"] == 0 &&
        isset($_FILES["data"]) && $_FILES["data"]["error"] == 0
    ) {
        $maxFileSize = 20 * 1024 * 1024; // 20MB in bytes
        if ($_FILES["image"]["size"] > $maxFileSize || $_FILES["data"]["size"] > $maxFileSize) {
            echo "<p>Error: The uploaded file exceeds the maximum size limit (20MB).</p>";
            echo "<p><a href='?deleteFiles=1'>Restart</a></p>";
            exit;
        }
 
        $uploadImage = $uploadDir . basename($_FILES["image"]["name"]);
        $uploadData = $uploadDir . basename($_FILES["data"]["name"]);

        $_SESSION['uploadImage'] = $uploadImage;
        $_SESSION['uploadData'] = $uploadData;
        
        if (
            move_uploaded_file($_FILES["image"]["tmp_name"], $uploadImage) &&
            move_uploaded_file($_FILES["data"]["tmp_name"], $uploadData)
        ) {
		if ($redditOption) {
			$command = "jdvrif conceal -r " . escapeshellarg($uploadImage) . " " . escapeshellarg($uploadData) . " 2>&1";
		} else if ($blueskyOption) {
			$command = "jdvrif conceal -b " . escapeshellarg($uploadImage) . " " . escapeshellarg($uploadData) . " 2>&1";
        } else {
			$command = "jdvrif conceal " . escapeshellarg($uploadImage) . " " . escapeshellarg($uploadData) . " 2>&1";
		}

            $output = shell_exec($command);
	    

            if (preg_match('/image:-\s*(.*?)Saved/s', $output, $matches_image)) {
                $platformContent = trim($matches_image[1]);
            } else {
                echo "Warning: Could not extract Platform Compatibility text.";
            }

            if (preg_match('/Recovery PIN:\s*(.*)/', $output, $matches_pin)) {
                $recoveryPin = trim($matches_pin[1]);
            } else {
                echo "Error: Recovery PIN Not Found! Program Failure.";
            }

            preg_match('/Saved "file-embedded" JPG image: ([^\s]+\.jpg)/', $output, $matches);
            if (!empty($matches[1])) {
                $savedFileName = $matches[1];

                $_SESSION['savedFileName'] = $savedFileName;

            echo "<p></p>";
            echo "<p></p>";
    		if (strpos($userAgent, 'Mobile') == true) {
                echo "<p><span style='color: lightblue; font-size: 1.3em; font-weight: bold;'>Complete!</span></p>";
                echo "<p></p>";
                echo "<p></p>";
                echo "<p><span style='color: coral; font-size: 0.63em; font-weight: bold;'>Platform compatibility for output image:-</span></p>";
                echo "<p><span style='color: chartreuse; font-size: 0.43em;'>" . $platformContent . "</span></p>";
                if ($blueskyOption) {
                    echo "<p><span style='color: aqua; font-size: 0.4em;'>You must use the <q>bsky_post.py</q> script (found in the repo src folder) to post the image to Bluesky.</span></p>";
                }
                echo "<p></p>";
                echo "<p></p>";
                echo "<p><span style='color: ghostwhite; font-size: 0.57em; font-weight: bold;'>Recovery PIN: " . $recoveryPin . "</span></p>";
                echo "<p><span style='color: crimson; font-size: 0.53em; font-weight: bold;'>Important: Keep your PIN safe, so that you can extract the hidden file.</span></p>";
                echo "<p></p>";
                echo "<p></p>";
                echo "<p><span style='color: ghostwhite; font-size: 0.4em;'>Tap cover image below to download</span></p>";
            } else {
                echo "<p><span style='color: lightblue; font-size: 1.45em; font-weight: bold;'>Complete!</span></p>";
                echo "<p><span style='color: coral; font-size: 1.1em; font-weight: bold;'>Platform compatibility for output image:-</span></p>";
                echo "<p><span style='color: chartreuse; font-size: 0.94em;'>" . $platformContent . "</span></p>";
                if ($blueskyOption) {
                    echo "<p><span style='color: aqua; font-size: 0.94em;'>You must use the <q>bsky_post.py</q> script (found in the repo src folder) to post the image to Bluesky.</span></p>";
                }
                echo "<p><span style='color: ghostwhite; font-size: 1.1em; font-weight: bold;'>Recovery PIN: " . $recoveryPin . "</span></p>";
                echo "<p><span style='color: crimson; font-size: 0.95em; font-weight: bold;'>Important: Keep your PIN safe, so that you can extract the hidden file.</span></p>";
                echo "<p>Click cover image below to download</p>";
    		}

            echo "<p><a href='$savedFileName' download><img src='$savedFileName' title='$savedFileName' alt='Image Link for Extracted File'></a></p>";

            if (strpos($userAgent, 'Mobile') == true) {
                echo "<p></p>";
                echo "<p><a href='?deleteFiles=1'<span style='color: lightblue; font-size: 0.5em;'>RESTART</span></a></p>";
            } else {
                echo "<p><a href='?deleteFiles=1'<span style='color: lightblue; font-size: 1em;'>RESTART</span></a></p>";
            }


            } else {
                echo "<p>Error: Unable to get the filename from jdvrif output. Program probably failed.</p></div>";
    		  echo "<p>Program output:</p>";
   		  echo "<pre>$output</pre>";
    		 echo "<p><a href='?deleteFiles=1'>Return to Home Page</a></p>";
            	exit;
            }
        } else {
            echo "<p>Error uploading the files.</p>";
             echo "<p><a href='?deleteFiles=1'>Return to Home Page</a></p>";
            	exit;
        }
    } else {
        echo "<p>Both Image and Data files must be chosen.</p>";
          echo "<p><a href='?deleteFiles=1'>Restart</a></p>";
            exit;
    }
}

if (isset($_GET['deleteFiles']) && $_GET['deleteFiles'] == 1) {

    // Retrieve stored file paths
    $uploadImage = $_SESSION['uploadImage'] ?? null;
    $uploadData = $_SESSION['uploadData'] ?? null;
    $savedFileName = $_SESSION['savedFileName'] ?? null;

    // Delete files if they exist
    if ($uploadImage && file_exists($uploadImage)) {
        unlink($uploadImage);
    }
    if ($uploadData && file_exists($uploadData)) {
        unlink($uploadData);
    }
    if ($savedFileName && file_exists($savedFileName)) {
        unlink($savedFileName);
    }

    // Clear session variables
    unset($_SESSION['uploadImage'], $_SESSION['uploadData'], $_SESSION['savedFileName']);

    header("Location: index");
    exit;
}
?>

