<?php
$uploadsDir_a = "/var/www/cleasbycode.co.uk/html/jdvrif/uploads/";
$uploadsDir_b = "/var/www/cleasbycode.co.uk/html/jdvrif/";

// Files to exclude from deletion
$excludeJdvrif = ['cleanup.php', 'jdvrif.html', 'index.html', 'insert.html', 'extract.html', 'insert.php', 'extract.php'];

// Get the current time
$currentTimestamp = time();

// Get all files in the uploads directory
$files_a = glob($uploadsDir_a . "*");

foreach ($files_a as $file_a) {
    if (is_file($file_a)) {
        $filename = basename($file_a);

        // Check if the file is in the exclusion list
        if (in_array($filename, $excludeJdvrif)) {
            continue;
        }

        // Get the file's creation time
        $creationTimestamp = filectime($file_a);

        // Check if the file is older than 5 minutes
        if ($currentTimestamp - $creationTimestamp >= 300) {
            // Delete the file
            unlink($file_a);
        }
    }
}

$files_b = glob($uploadsDir_b . "*");

foreach ($files_b as $file_b) {
    if (is_file($file_b)) {
        $filename = basename($file_b);

        // Check if the file is in the exclusion list
        if (in_array($filename, $excludeJdvrif)) {
            continue;
        }

        // Get the file's creation time
        $creationTimestamp = filectime($file_b);

        // Check if the file is older than 5 minutes
        if ($currentTimestamp - $creationTimestamp >= 300) {
            // Delete the file
            unlink($file_b);
        }
    }
}

?>
