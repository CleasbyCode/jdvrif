<?php

session_start();

function bcmath_pack_64bit(string $number): string {
    $high = bcdiv($number, '4294967296'); // Divide by 2^32
    $low = bcmod($number, '4294967296'); // Get remainder

    return pack('NN', (int) $high, (int) $low);
}

$jdvrifDir = "/var/www/cleasbycode.co.uk/html/jdvrif/";
$uploadDir = "uploads/"; 

$userAgent = $_SERVER['HTTP_USER_AGENT'];

if (strpos($userAgent, 'Mobile') == true) {
	echo "<style> body{background-color:#111111;color:aliceblue;font-family:Math;font-size:2.3em;text-align:center;min-height:100vh;}";
	echo "h1{font-size:2.7em;font-weight:bold;margin-top:38px;margin-bottom:20px;color:#faaaaa;}img{max-width: 42%; max-height: 35%;border:2px solid silver;border-radius:14px;}p{margin: 4px 0;line-height: 1.3;}button:focus,button:active{outline:none;}</style>";
} else {
	echo "<style> body{background-color:#111111;color:aliceblue;font-family:Math;font-size:1.6em;text-align:center;}";
	echo "h1{font-size:1.7em;font-weight:bold;margin-top:24px;margin-bottom:-12px;color:#faaaaa;}img{max-width: 22%; max-height: 16%;border:2px solid silver;border-radius:14px;}img:hover{border-color:orange;}p{margin:6px 0;line-height:1.4;}button:focus,button:active{outline:none;}</style>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if a file was uploaded
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        // Check the file size (200MB limit)
        $maxFileSize = 20 * 1024 * 1024; // 20MB in bytes
        if ($_FILES["image"]["size"] > $maxFileSize) {
            echo "<p>Error: The uploaded file exceeds the maximum size limit (20MB).</p>";
            echo "<p><a href='?deleteFiles=1'>RESTART</a></p>";
            exit;
        }
        
        $uploadFile = $uploadDir . basename($_FILES["image"]["name"]);

        $_SESSION['uploadFile'] = $uploadFile;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadFile)) {
            $PIN = $_POST["pin"] ?? "";

            $PinFilePath = $uploadDir . "pin_" . substr(md5(uniqid()), 0, 8) . ".txt";

            $_SESSION['PinFilePath'] = $PinFilePath;

            if (!preg_match('/^\d{19,20}$/', $PIN)) {
                $INT_PIN = (int)$PIN;
                $BIN_PIN = pack('J', $INT_PIN);
                file_put_contents($PinFilePath, $BIN_PIN);
            } else {
                $BIN_PIN = bcmath_pack_64bit($PIN);
                file_put_contents($PinFilePath, $BIN_PIN);
            }

            $command = "jdvrif recover " . escapeshellarg($uploadFile) . " " . escapeshellarg($PinFilePath) . " 2>&1";
            // file_put_contents($CommandPath, $command);
            $output = shell_exec($command);

           // Find the filename in the output
preg_match('/Extracted hidden file:\s(\S+)/', $output, $matches);
if (!empty($matches[1])) {
    $savedFileName = $matches[1];

    $_SESSION['savedFileName'] = $savedFileName;

     echo "<p></p>";
     echo "<p></p>";
     echo "<p><span style='color: lightblue; font-size: 1.45em; font-weight: bold;'>Complete!</span></p>";
     echo "<p>Recovered file: <span style='color: lightsteelblue;font-style: italic;'>&ldquo;$savedFileName&rdquo;</span><p>";
     if (strpos($userAgent, 'Mobile') == true) {
    		echo "<p>Tap image below to download extracted file</p>";
		} else {
    		echo "<p>Click image below to download extracted file</p>";
    		}
     echo "<p><a href='$savedFileName' download><img src='img/chest_jdv.png' title='$savedFileName' alt='Image Link for Extracted File'></a></p>";
     echo "<p><a href='?deleteFiles=1'><span style='color: burlywood;'>RESTART</span></a></p>";
} else {
    echo "<br>";
    echo "<p>Error: Unable to extract filename from jdvout.</p>";
      echo "<p>Program output:</p>";
    echo "<pre>$output</pre>";
    echo "<p><a href='?deleteFiles=1'>RESTART</a></p>";
             exit;
}
        } else {
            echo "<p>Error uploading the image.</p>";
            echo "<p><a href='?deleteFiles=1'>RESTART</a></p>";
             exit;
        }
    } else {
        echo "<p>No image uploaded or an error occurred.</p>";
        echo "<p><a href='?deleteFiles=1'>RESTART</a></p>";
                exit;
    }
}
echo "</div>";

if (isset($_GET['deleteFiles']) && $_GET['deleteFiles'] == 1) {

    // Retrieve stored file paths
    $uploadFile = $_SESSION['uploadFile'] ?? null;
    $savedFileName = $_SESSION['savedFileName'] ?? null;
    $PinFilePath = $_SESSION['PinFilePath'] ?? null;

    // Delete files if they exist
    if ($uploadFile && file_exists($uploadFile)) {
        unlink($uploadFile);
    }

    if ($PinFilePath && file_exists($PinFilePath)) {
        unlink($PinFilePath);
    }

    if ($savedFileName && file_exists($savedFileName)) {
        unlink($savedFileName);
    }

    // Clear session variables
    unset($_SESSION['uploadImage'], $_SESSION['uploadData'], $_SESSION['savedFileName']);

    header("Location: index");
    exit;
}
?>

