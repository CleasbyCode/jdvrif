#include "args_out.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string& usage) {
  throw std::runtime_error(usage);
}

namespace {
[[nodiscard]] const char* requireArg(int argc, char** argv, int index, const std::string& usage) {
  if (argv == nullptr || index < 0 || index >= argc || argv[index] == nullptr) {
    ProgramArgs::die(usage);
  }
  return argv[index];
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
  const std::string prog = (argc >= 1 && argv != nullptr && argv[0] != nullptr) ? fs::path(argv[0]).filename().string() : std::string{"wpdv_out"};
  const std::string usage = std::format("Usage: {} <cover_image> <pin_file>", prog);

  if (argc != 3 || std::string_view(requireArg(argc, argv, 1, usage)).empty() || std::string_view(requireArg(argc, argv, 2, usage)).empty()) {
    die(usage);
  }

  ProgramArgs out{};
  out.image_file_path = requireArg(argc, argv, 1, usage);
  out.pin_file_path = requireArg(argc, argv, 2, usage);
  return out;
}
