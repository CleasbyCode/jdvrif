#include "args_out.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string& usage) {
  throw std::runtime_error(usage);
}
ProgramArgs ProgramArgs::parse(int argc, char** argv) {
  const std::string prog = fs::path(argv[0]).filename().string();
  const std::string usage = std::format("Usage: {} <cover_image> <pin_file>", prog);

  if (argc != 3 || std::string_view(argv[1]).empty() || std::string_view(argv[2]).empty()) {
    die(usage);
  }

  ProgramArgs out{};
  out.image_file_path = argv[1];
  out.pin_file_path = argv[2];
  return out;
}
