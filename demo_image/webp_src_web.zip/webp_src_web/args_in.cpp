#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string& usage) {
  throw std::runtime_error(usage);
}
ProgramArgs ProgramArgs::parse(int argc, char** argv) {
  const std::string prog = fs::path(argv[0]).filename().string();
  const std::string usage = std::format("Usage: {} [-b] <cover_image> <secret_file>", prog);

  ProgramArgs out{};
  int i = 1;

  if (i < argc && std::string_view(argv[i]) == "-b") {
    out.option = Option::Bluesky;
    ++i;
  }

  if (i + 2 != argc || std::string_view(argv[i]).empty() || std::string_view(argv[i + 1]).empty()) {
    die(usage);
  }

  out.image_file_path = argv[i];
  out.data_file_path = argv[i + 1];
  return out;
}
