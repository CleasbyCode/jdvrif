// WEBP Data Vehicle (wpdv_out) Created by Nicholas Cleasby (@CleasbyCode) 13/11/2024

#include "args_out.h"
#include "io_utils.h"
#include "recover.h"

#include <iostream>
#include <print>
#include <stdexcept>

int main(int argc, char** argv) {
  try {
    if (sodium_init() < 0) {
      throw std::runtime_error("Libsodium initialization failed!");
    }

    const auto args = ProgramArgs::parse(argc, argv);
    vBytes image_vec = readFile(args.image_file_path, FileTypeCheck::embedded_image);
    vBytes pin_vec = readFile(args.pin_file_path, FileTypeCheck::pin_file);
    recoverData(image_vec, pin_vec);
  } catch (const std::exception& e) {
    std::println(std::cerr, "\n{}\n", e.what());
    return 1;
  }

  return 0;
}
