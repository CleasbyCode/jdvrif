
#pragma once

#include <vector>
#include <cstdint>

void transcodeImage(std::vector<uint8_t>&, bool);
