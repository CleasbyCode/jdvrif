#pragma once

#include <iostream>

void displayInfo();
