#pragma once

#include <string>

std::string convertString(const std::wstring&);
