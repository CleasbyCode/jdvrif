
#pragma once

#include <vector>
#include <cstdint>

void valueUpdater(std::vector<uint8_t>&, uint32_t, const uint32_t, uint8_t);
