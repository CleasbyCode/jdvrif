#include "program_args_out.h"

#include <format>
#include <stdexcept>

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
    const std::string
        PROG = fs::path(argv[0]).filename().string(),
        USAGE = std::format("Usage: {} <cover_image> <pin_file>", PROG);

    if (argc != 3)
        die(USAGE);

    ProgramArgs out;
    out.image_file_path = argv[1];
    out.pin_file_path   = argv[2];
    return out;
}

[[noreturn]] void ProgramArgs::die(const std::string& message) {
    throw std::runtime_error(message);
}
