#include "program_args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
    const auto arg = [&](int i) -> std::string_view {
        return (i >= 0 && i < argc) ? std::string_view(argv[i]) : std::string_view{};
    };

    const std::string
        PROG = fs::path(argv[0]).filename().string(),
        USAGE = std::format("Usage: {} [-b|-r] <cover_image> <secret_file>", PROG);

    ProgramArgs out;
    int i = 1;

    if (arg(i) == "-b") {
        out.option = Option::Bluesky;
        ++i;
    } else if (arg(i) == "-r") {
        out.option = Option::Reddit;
        ++i;
    }

    if (argc != i + 2)
        die(USAGE);

    out.image_file_path = arg(i);
    out.data_file_path  = arg(i + 1);
    return out;
}

[[noreturn]] void ProgramArgs::die(const std::string& message) {
    throw std::runtime_error(message);
}
