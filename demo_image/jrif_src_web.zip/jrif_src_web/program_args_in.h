#pragma once

#include "common.h"

#include <string>

struct ProgramArgs {
    Option option{Option::None};
    fs::path image_file_path;
    fs::path data_file_path;

    static ProgramArgs parse(int argc, char** argv);

private:
    [[noreturn]] static void die(const std::string& message);
};
