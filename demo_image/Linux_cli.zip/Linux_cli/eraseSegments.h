
#pragma once

#include <vector>
#include <cstdint>

void eraseSegments(std::vector<uint8_t>&);
