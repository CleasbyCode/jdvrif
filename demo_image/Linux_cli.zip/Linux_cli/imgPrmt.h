#pragma once

#include "programArgs.h"
#include <string>

int imgPrmt(const std::string&, ArgOption);
