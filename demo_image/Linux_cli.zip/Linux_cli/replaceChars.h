#pragma once

#include <string>

void replaceProblemChars(std::wstring&);
