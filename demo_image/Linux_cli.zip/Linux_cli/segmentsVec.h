#pragma once

#include <vector>
#include <cstdint>

extern std::vector<uint8_t> Profile_Vec;
extern std::vector<uint8_t> Segment_Vec;
extern std::vector<uint8_t> BlueSky_Vec;
