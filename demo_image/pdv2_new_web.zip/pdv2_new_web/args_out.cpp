#include "args_out.h"

#include <format>
#include <stdexcept>
#include <string_view>

[[noreturn]] static void dieUsage(const std::string& usage) {
	throw std::runtime_error(usage);
}

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const auto arg = [&](int i) -> std::string_view {
		if (i < 0 || i >= argc) return {};
		const char* const s = argv[i];
		return s ? std::string_view{s} : std::string_view{};
	};

	// POSIX permits argc == 0 and argv[0] == nullptr; fall back to the binary name.
	const std::string
		prog = (argc >= 1 && argv[0] != nullptr)
			? fs::path(argv[0]).filename().string()
			: std::string{"pdv_out"},
		usage = std::format("Usage: {} <cover_image> <pin_file>", prog);

	if (argc != 3 || arg(1).empty() || arg(2).empty()) dieUsage(usage);

	ProgramArgs out{};
	out.image_file_path = fs::path(arg(1));
	out.pin_file_path = fs::path(arg(2));
	return out;
}
