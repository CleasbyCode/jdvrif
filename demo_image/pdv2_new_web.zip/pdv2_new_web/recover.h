#pragma once

#include "common.h"

void recoverData(vBytes& png_vec, const fs::path& pin_file_path);
